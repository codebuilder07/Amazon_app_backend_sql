/*aspect 1 */
create or replace procedure add_product(
product_id_proc in decimal,
seller_id_proc in decimal,
categories_id_proc in decimal,
product_name_proc in varchar,
product_details_proc in varchar,
product_price_proc in decimal,
product_inventory_proc in decimal)
is
begin
insert into product
(product_id, seller_id ,categories_id, product_name, product_details,
product_price,product_inventory)
values(product_id_proc, seller_id_proc, categories_id_proc, product_name_proc,
product_details_proc, product_price_proc,product_inventory_proc);
end;
/
begin
add_product(3010,1008,2002,'self?driving video camera','automatically follows a
subject that is being recorded',159.99,80);
End;
/
begin
add_product(3011,1010,2002,'holographic keyboard','Lemits a three?dimensional
projection of a keyboard and recognizes virtual key presses from the
typist',183.47,98);
End;
/
select* from product;
/*aspect 2 */
Create or replace procedure add_orders(
orders_id_proc in decimal,
customerz_id_proc in decimal,
product_id_proc in decimal,
orders_sold_proc in decimal
)
is
begin
insert into orders
(orders_id, customerz_id ,product_id, orders_sold)
values
(orders_id_proc, customerz_id_proc ,product_id_proc,orders_sold_proc);
End;
/
select customerz_id from orders where orders_id= 6001;
begin
add_orders(6008,5003,3010,8);
End;
/
begin
add_orders(6009,5002,3011,9);
End;
/
select * from orders;

set product_inventory = product_inventory -75
where product_name = 'self?driving video camera';
update product
set product_inventory = product_inventory - 90
where product_name = 'holographic keyboard';
select product_name,product_details,product_price,product_inventory
from product
where product_inventory <=11;

/*aspect 3 */
Create or replace procedure add_address(
address_id_arg in decimal,
address_address_arg in varchar,
address_city_arg in varchar,
address_state_arg in varchar,
address_pincode_arg in decimal)
is
begin
insert into address
(address_id ,address_address ,address_city ,address_state ,address_pincode )
values(address_id_arg, address_address_arg, address_city_arg, address_state_arg,
address_pincode_arg);
End;
/
Begin
add_address(4008,'19 Disco','Worcester','MA', 01609);
End;
/
begin
add_address(4009,'51 Old pier St','Worcester','MA',01610);
End;
/
Begin
add_address(4010,'4 Beavwer St','Mancester','MA',09878);
End;
/
Begin
add_address(4011,'19 Palmer St','Worcester','MA', 01619);
End;
/
create or replace procedure add_customerz(
customerz_id_proc in decimal,
address_id_proc decimal,
customerz_firstname_proc in varchar,
customerz_lastname_proc in varchar,
customerz_email_proc in varchar,
customerz_phone_proc in decimal)
is
begin
insert into customerz
(customerz_id,address_id,customerz_firstname, customerz_lastname, customerz_email,
customerz_phone)
values(customerz_id_proc, address_id_proc,customerz_firstname_proc, customerz_lastname_proc,
customerz_email_proc, customerz_phone_proc);
end;
/

begin
add_customerz(5008,4008,'Nikhil','jacob','njake@gmail.com','7768977890');
 /
begin
add_customerz(5009,4009,'Nivin','jacob','njake@gmail.com','8907652342');
End;
/
begin
add_customerz(5010,4010,'Jack','jacob','jj@gmail.com','7798976534');
End;
/
begin
add_customerz(5011,4011,'Kristina ','jacob','krisj@clarku.edu','7767894509');
End;
/

select customerz.customerz_firstname,customerz.customerz_lastname,
customerz.customerz_email,customerz.customerz_phone,
address.address_address,address.address_city,address.address_state,
address.address_pincode
from address
left join customerz on customerz.address_id = address.address_id
where customerz.customerz_lastname = 'jacob';
select* from orders;
/*aspect 4 */
/*stored procedure add_order created in aspect 2 */

begin
add_orders(6010,5008,3010,1);
End;
/
begin
add_orders(6011,5011,3011,3);
End;
/
begin
add_orders(6012,5002,3010,6);
End;
/
begin
add_orders(6013,5010,3001,5);
End;
/
begin
add_orders(6014,5008,3010,7);
End;
/
begin
add_orders(6015,5008,3003,3);
End;
/
select product_id, sum(orders_sold) as sum_orders_sold
from orders
group by product_id
order by sum_orders_sold details;
select product.product_name, customerz.customerz_firstname,customerz.customerz_lastname,address.address_address,address.address_city,address.address_state,address.address_pincode
from orders
join customerz on customerz.customerz_id = orders.customerz_id
join product on product.product_id = orders.product_id
join address on address.address_id = customerz.address_id
where product_name = 'self driving video camera';
/**/
select * from orders;

/*aspect 5 */
create table delivery(
shipped_id decimal(10) PRIMARY KEY,
orders_id decimal(10) not null);

ALTER TABLE delivery
ADD CONSTRAINT order_delivery_fk
FOREIGN KEY(orders_id)
REFERENCES orders(orders_id);

Create or replace procedure shipment_proc(
shipped_id_proc in decimal,
orders_id_proc in decimal)
is
begin
insert into delivery(shipped_id, orders_id)
values(shipped_id_proc,orders_id_proc);
End;
/
begin
shipment_proc(7001,6008);
End;
/
begin
shipment_proc(7002,6010);
End;
/
begin
shipment_proc(7003,6014);
End;
/

select delivery.shipped_id, product.product_name,
customerz.customerz_firstname,customerz.customerz_lastname,customerz.customerz_email,
address.address_address,address.address_city,address.address_state,address.address_pincode
from delivery
join orders on orders.orders_id = delivery.orders_id
join product on product.product_id = orders.product_id
join customerz on customerz.customerz_id = orders.customerz_id
join address on address.address_id = customerz.address_id
/*END */